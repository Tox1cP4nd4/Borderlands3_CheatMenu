#include <iostream>
#include <Windows.h>
#include <TlHelp32.h>
#include <string>
#include <vector>
#include "Offsets.h"

namespace Cheat
{
	struct {
		// ESP
		bool espActive = false;

		//AIMBOT
		bool aimbotActive = false;

		//WORLD

		//MISC
		bool immortal = false;
		bool unlimitedAmmo = false;
		bool noReload = false;

		//SETTINGS


		LPCSTR WINDOW_NAME = "Borderlands3.exe";
		LPCSTR MODULE_NAME = "server.dll";

		//uintptr_t gameModuleName;
		uintptr_t moduleBase;
		DWORD procId;
		HWND hwnd;
		HANDLE hProcess;

		uintptr_t GetModuleBaseAddress(const char* modName) {
			HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, procId);
			if (hSnap != INVALID_HANDLE_VALUE) {
				MODULEENTRY32 modEntry;
				modEntry.dwSize = sizeof(modEntry);
				if (Module32First(hSnap, &modEntry)) {
					do {
						if (!strcmp(modEntry.szModule, modName)) {
							CloseHandle(hSnap);
							return (uintptr_t)modEntry.modBaseAddr;
						}
					} while (Module32Next(hSnap, &modEntry));
				}
			}
		}

		void initialize() {
			std::cout << "Initializing..." << std::endl;
			hwnd = FindWindowA(NULL, WINDOW_NAME);
			std::cout << "HWND: " << hwnd << std::endl;
			GetWindowThreadProcessId(hwnd, &procId);
			std::cout << "ProdID: " << procId << std::endl;
			//gameModuleName = (uintptr_t)GetModuleHandle(WINDOW_NAME); // check if works
			//std::cout << gameModuleName << std::endl;
			moduleBase = GetModuleBaseAddress(MODULE_NAME);
			std::cout << "moduleBase: " << moduleBase << std::endl;
			hProcess = OpenProcess(PROCESS_ALL_ACCESS, NULL, procId);
		}

		uintptr_t FindDMAAddy(HANDLE hProc, uintptr_t ptr, std::vector<unsigned int> offsets)
		{
			uintptr_t addr = ptr;
			for (unsigned int i = 0; i < offsets.size(); ++i)
			{
				ReadProcessMemory(hProc, (BYTE*)addr, &addr, sizeof(addr), 0);
				addr += offsets[i];
			}
			return addr;
		}

		template<typename T> T RPM(SIZE_T address) {
			T buffer;
			ReadProcessMemory(hProcess, (LPCVOID)address, &buffer, sizeof(T), NULL);
			return buffer;
		}

		template<typename T> void WPM(SIZE_T address, T buffer) {
			WriteProcessMemory(hProcess, (LPVOID)address, &buffer, sizeof(buffer), NULL);
		}

		void funcUnlimitedAmmo() {
			std::cout << "funcUnlimitedAmmo Running..." << std::endl;
			std::vector<unsigned int> ammoOffsets = { 0x48, 0x8, 0x470, 0x150, 0x388 };
			uintptr_t ammoAddr = FindDMAAddy(hProcess, moduleBase + 0x06519348, ammoOffsets);
			float ammoAtual = RPM<float>(ammoAddr);
			if (ammoAtual >= 0 && ammoAtual != 200.0) { // Verifies if the address is correct
				WPM<float>(ammoAddr, 200.0);
			}
		}

		void funcImortal() {
			std::vector<unsigned int> healthOffsets = { 0x70, 0x8, 0x470, 0x150, 0x198 };
			uintptr_t healthAddr = FindDMAAddy(hProcess, moduleBase + 0x06B0FAB8, healthOffsets);
			float healthAtual = RPM<float>(healthAddr);
			if (healthAtual >= 0 && healthAtual != 95.0) { // Verifies if the address is correct
				WPM<float>(healthAddr, 95.0);
			}
		}

	}cheatOptions;

}

