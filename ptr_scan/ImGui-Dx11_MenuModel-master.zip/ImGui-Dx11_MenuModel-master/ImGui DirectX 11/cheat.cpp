#include <iostream>
#include <Windows.h>
#include <TlHelp32.h>
#include <vector>
#include "Offsets.h"

uintptr_t moduleBase;

DWORD procId;
HWND hwnd;
HANDLE hProcess;

uintptr_t GetModuleBaseAddress(DWORD procId, const char* modName)
{
	uintptr_t modBaseAddr = 0;
	HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, procId);
	if (hSnap != INVALID_HANDLE_VALUE)
	{
		MODULEENTRY32 modEntry;
		modEntry.dwSize = sizeof(modEntry);
		if (Module32First(hSnap, &modEntry))
		{
			do
			{
				if (!strcmp(modEntry.szModule, modName))
				{
					modBaseAddr = (uintptr_t)modEntry.modBaseAddr;
					break;
				}
			} while (Module32Next(hSnap, &modEntry));
		}
	}
	CloseHandle(hSnap);
	return modBaseAddr;
}

uintptr_t FindDMAAddy(HANDLE hProc, uintptr_t ptr, std::vector<unsigned int> offsets)
{
	uintptr_t addr = ptr;
	for (unsigned int i = 0; i < offsets.size(); ++i)
	{
		ReadProcessMemory(hProc, (BYTE*)addr, &addr, sizeof(addr), 0);
		addr += offsets[i];
	}
	return addr;
}

template<typename T> T RPM(SIZE_T address) {
	T buffer;
	ReadProcessMemory(hProcess, (LPCVOID)address, &buffer, sizeof(T), NULL);
	return buffer;
}

template<typename T> void WPM(SIZE_T address, T buffer) {
	WriteProcessMemory(hProcess, (LPVOID)address, &buffer, sizeof(buffer), NULL);
}

/*
int main() {

	hwnd = FindWindowA(NULL, "AssaultCube");
	GetWindowThreadProcessId(hwnd, &procId);
	moduleBase = GetModuleBaseAddress(procId, "ac_client.exe");
	hProcess = OpenProcess(PROCESS_ALL_ACCESS, NULL, procId);

	uintptr_t dynamicPtrBaseAddr = moduleBase + 0x0011E20C;
	std::vector<unsigned int> ammoOffsets = { 0x360, 0x44, 0x14 };
	uintptr_t ammoAddr = FindDMAAddy(hProcess, dynamicPtrBaseAddr, ammoOffsets);

	std::vector<unsigned int> healthOffsets = { 0x36c, 0x8, 0xf8 };
	uintptr_t healthAddr = FindDMAAddy(hProcess, dynamicPtrBaseAddr, healthOffsets);

	std::cout << "HWND: " << hwnd << std::endl;
	std::cout << "ModuleBaseAddr = " << "0x" << std::hex << moduleBase << std::endl;
	std::cout << "DynamicPtrBaseAddr = " << "0x" << std::hex << dynamicPtrBaseAddr << std::endl;
	std::cout << "ammoAddr = " << "0x" << std::hex << ammoAddr << std::endl;

	while (true) {
		WPM<int>(ammoAddr, 1337);
		WPM<int>(healthAddr, 1337);
	}

}
*/