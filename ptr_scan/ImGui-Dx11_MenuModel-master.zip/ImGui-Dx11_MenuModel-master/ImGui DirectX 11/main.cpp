#include "includes.h"
#include "settings.h"
#include "source.cpp"
#include <string>
#include <iostream>
#include <vector>
#include <d3d11.h>
#include <tchar.h>

const int DIRECTX11_WINDOW_WIDTH = 600;
const int DIRECTX11_WINDOW_HEIGHT = 300;

// Data
static ID3D11Device* g_pd3dDevice = NULL;
static ID3D11DeviceContext* g_pd3dDeviceContext = NULL;
static IDXGISwapChain* g_pSwapChain = NULL;
static ID3D11RenderTargetView* g_mainRenderTargetView = NULL;

// Forward declarations of helper functions
bool CreateDeviceD3D(HWND hWnd);
void CleanupDeviceD3D();
void CreateRenderTarget();
void CleanupRenderTarget();
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

HWND hWnd;
POINTS position = { }; // Points for window movement

int main(int, char**)
{
    // Create application window
    WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, WndProc, 0L, 0L, GetModuleHandle(NULL), NULL, NULL, NULL, NULL, _T("ImGui Example"), NULL };
    ::RegisterClassEx(&wc);
    hWnd = ::CreateWindow(
        wc.lpszClassName, _T("ImGui-DX11 Menu-UI Example"),
        WS_OVERLAPPEDWINDOW, 100, 100, // window pos
        DIRECTX11_WINDOW_WIDTH, DIRECTX11_WINDOW_HEIGHT, NULL, NULL, wc.hInstance, NULL);
    //SetWindowLong(hwnd, GWL_STYLE, CS_CLASSDC); // Remove window style

    // Initialize Direct3D
    if (!CreateDeviceD3D(hWnd))
    {
        CleanupDeviceD3D();
        ::UnregisterClass(wc.lpszClassName, wc.hInstance);
        return 1;
    }

    // Show the window
    ::ShowWindow(hWnd, SW_SHOWDEFAULT);
    ::UpdateWindow(hWnd);

    // Setup Dear ImGui context
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;

    // Setup Dear ImGui style
    ImGui::StyleColorsDark();
    //ImGui::StyleColorsClassic();

    // Setup Platform/Renderer backends
    ImGui_ImplWin32_Init(hWnd);
    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

    bool show_another_window = false;
    ImVec4 clear_color = ImVec4(0.45f, 0.55f, 0.60f, 1.00f);

    Cheat::cheatOptions.initialize(); // Initialize cheat source code

    // Main loop
    bool done = false;
    bool isRunning = true;
    while (!done && isRunning)
    {
        if (GetAsyncKeyState(VK_END) & 1) { // END key close the menu
            return 0;
            //break;
        }

        if ( Cheat::cheatOptions.unlimitedAmmo ) {
            Cheat::cheatOptions.funcUnlimitedAmmo();
        }

        if (Cheat::cheatOptions.immortal) {
            Cheat::cheatOptions.funcImortal();
        }

        if (Cheat::cheatOptions.noReload) {
            //
        }

        // Poll and handle messages (inputs, window resize, etc.)
        // See the WndProc() function below for our to dispatch events to the Win32 backend.
        MSG msg;
        while (::PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE))
        {
            ::TranslateMessage(&msg);
            ::DispatchMessage(&msg);
            if (msg.message == WM_QUIT)
                done = true;
        }
        if (done)
            break;

        // Start the Dear ImGui frame
        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        // ImGui Window
        {
            static float f = 0.0f;
            static int counter = 0;

            ImGui::SetNextWindowSize(ImVec2((float)DIRECTX11_WINDOW_WIDTH - 16, (float)DIRECTX11_WINDOW_HEIGHT - 16));
            ImGui::SetNextWindowPos({ 0, 0 });

            ImGui::Begin("ImGui Window Menu Example", &isRunning, 
                ImGuiWindowFlags_NoResize |
                ImGuiWindowFlags_NoSavedSettings |
                ImGuiWindowFlags_NoCollapse |
                ImGuiWindowFlags_NoMove|
                ImGuiWindowFlags_NoTitleBar);   

            ImGui::Columns(2);
            ImGui::SetColumnOffset(1, 160);

            // Left items (menu buttons)
            {
                if (ImGui::Button("ESP", ImVec2(150, 45)))
                    Settings::Tab = 1;

                //ImGui::Spacing();
                if (ImGui::Button("Aimbot", ImVec2(150, 45)))
                    Settings::Tab = 2;

                //ImGui::Spacing();
                if (ImGui::Button("World", ImVec2(150, 45)))
                    Settings::Tab = 3;

                //ImGui::Spacing();
                if (ImGui::Button("MISC", ImVec2(150, 45)))
                    Settings::Tab = 4;

                //ImGui::Spacing();
                if (ImGui::Button("Settings", ImVec2(150, 45)))
                    Settings::Tab = 5;

            }

            ImGui::NextColumn();

            { // Right side 

                switch (Settings::Tab) {
                    case(1): {
                        ImGui::Text("ESP"); 
                        ImGui::Spacing();
                        ImGui::Checkbox("Active", &Cheat::cheatOptions.espActive);
                    }break;
                    case(2): {
                        ImGui::Text("Aimbot");
                        ImGui::Spacing();
                        ImGui::Checkbox("Active", &Cheat::cheatOptions.aimbotActive);
                    }break;
                    case(3): {
                        ImGui::Text("World");
                        ImGui::Spacing();
                    }break;
                    case(4): {
                        ImGui::Text("MISC");
                        ImGui::Spacing();
                        ImGui::Checkbox("Unlimited Ammo", &Cheat::cheatOptions.unlimitedAmmo);
                        ImGui::Checkbox("No Reload", &Cheat::cheatOptions.noReload);
                        ImGui::Checkbox("Immortal(crashing) ", &Cheat::cheatOptions.immortal);
                    }break;
                    case(5): {
                        ImGui::Text("Settings");
                        ImGui::Spacing();
                        ImGui::ColorEdit3("Background Color", (float*)&clear_color); 
                        ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);

                    }break;
                    default:
                        break;
                }
                    
            }

            ImGui::End();
        }

        // 3. Show another simple window.
        if (show_another_window)
        {
            ImGui::Begin("Another Window", &show_another_window);   // Pass a pointer to our bool variable (the window will have a closing button that will clear the bool when clicked)
            ImGui::Text("Hello from another window!");
            if (ImGui::Button("Close Me"))
                show_another_window = false;
            ImGui::End();
        }

        // Rendering
        ImGui::Render();
        const float clear_color_with_alpha[4] = { clear_color.x * clear_color.w, clear_color.y * clear_color.w, clear_color.z * clear_color.w, clear_color.w };
        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, NULL);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear_color_with_alpha);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

        g_pSwapChain->Present(1, 0); // Present with vsync
        //g_pSwapChain->Present(0, 0); // Present without vsync
    }

    // Cleanup
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    CleanupDeviceD3D();
    ::DestroyWindow(hWnd);
    ::UnregisterClass(wc.lpszClassName, wc.hInstance);  

    return 0;
}

// Helper functions

bool CreateDeviceD3D(HWND hWnd)
{
    // Setup swap chain
    DXGI_SWAP_CHAIN_DESC sd;
    ZeroMemory(&sd, sizeof(sd));
    sd.BufferCount = 2;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    UINT createDeviceFlags = 0;
    //createDeviceFlags |= D3D11_CREATE_DEVICE_DEBUG;
    D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
    if (D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext) != S_OK)
        return false;

    CreateRenderTarget();
    return true;
}

void CleanupDeviceD3D()
{
    CleanupRenderTarget();
    if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = NULL; }
    if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = NULL; }
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = NULL; }
}

void CreateRenderTarget()
{
    ID3D11Texture2D* pBackBuffer;
    g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
    g_pd3dDevice->CreateRenderTargetView(pBackBuffer, NULL, &g_mainRenderTargetView);
    pBackBuffer->Release();
}

void CleanupRenderTarget()
{
    if (g_mainRenderTargetView) { g_mainRenderTargetView->Release(); g_mainRenderTargetView = NULL; }
}

// Forward declare message handler from imgui_impl_win32.cpp
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// Win32 message handler
// You can read the io.WantCaptureMouse, io.WantCaptureKeyboard flags to tell if dear imgui wants to use your inputs.
// - When io.WantCaptureMouse is true, do not dispatch mouse input data to your main application, or clear/overwrite your copy of the mouse data.
// - When io.WantCaptureKeyboard is true, do not dispatch keyboard input data to your main application, or clear/overwrite your copy of the keyboard data.
// Generally you may always pass all inputs to dear imgui, and hide them from your application based on those two flags.
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    switch (msg)
    {
    case WM_SIZE:
        if (g_pd3dDevice != NULL && wParam != SIZE_MINIMIZED)
        {
            CleanupRenderTarget();
            g_pSwapChain->ResizeBuffers(0, (UINT)LOWORD(lParam), (UINT)HIWORD(lParam), DXGI_FORMAT_UNKNOWN, 0);
            CreateRenderTarget();
        }
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU) // Disable ALT application menu
            return 0;
        break;
    case WM_DESTROY:
        ::PostQuitMessage(0);
    case WM_LBUTTONDOWN: {
        position = MAKEPOINTS(lParam); // set click points
    }return 0;
    case WM_MOUSEMOVE: {
        if (wParam == MK_LBUTTON)
        {
            const auto points = MAKEPOINTS(lParam);
            auto rect = ::RECT{ };

            GetWindowRect(hWnd, &rect);

            rect.left += points.x - position.x;
            rect.top += points.y - position.y;

            if (position.x >= 0 &&
                position.x <= DIRECTX11_WINDOW_WIDTH &&
                position.y >= 0 && position.y <= 19)
                SetWindowPos(
                    hWnd,
                    HWND_TOPMOST,
                    rect.left,
                    rect.top,
                    0, 0,
                    SWP_SHOWWINDOW | SWP_NOSIZE | SWP_NOZORDER
                );
        }

    }
        return 0;
    }
    return ::DefWindowProc(hWnd, msg, wParam, lParam);
}